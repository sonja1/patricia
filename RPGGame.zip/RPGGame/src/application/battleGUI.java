package application;

import javafx.scene.Group;
import javafx.scene.Scene;


import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.transform.Rotate;




public class battleGUI{
	private int width = 36;
	private int height = 24;
	private static int cornersize = 25;
	
	
	//creating the stage for battleGUI
	public void battleStage(mainMap3 mOrgin){
		
		try {
			
			//this shows the image of player
			ImageView mv1 = new ImageView();
			Image p1 = new Image("file:Images/main-player.png");
			mv1.setImage(p1);
			mv1.setFitWidth(200);
			mv1.setFitHeight(200);
			mv1.setLayoutX(120);
			mv1.setLayoutY(90);
			
			//this shows the image of enemy
			ImageView mv2 = new ImageView();
			Image e1 = new Image("file:Images/enemy.png");
			mv2.setImage(e1);
			mv2.setFitWidth(200);
			mv2.setFitHeight(200);
			mv2.setLayoutX(570);
			mv2.setLayoutY(30);
			
			// this button takes you back to the map
			Button b = new Button("End turn");
			b.setPrefSize(225,69);
			b.setLayoutX(599);
			b.setLayoutY(480);
			b.setStyle("-fx-font-size: 3em; -fx-background-color: #f80606");
			b.setOnAction(e -> mainMap3.getPrimaryStage().setScene(mainMap3.getScene2()));
			
			// this button allows you to use the selected item
			Button b2 = new Button("Use move 1");
			b2.setPrefSize(98,25);
			b2.setLayoutX(726);
			b2.setLayoutY(433);
			// use this to have the button do what you need b.setOnAction(e -> );
			
			//this button returns move1
			Button m1 = new Button("Use move 2");
			m1.setPrefSize(133,79);
			m1.setLayoutX(65);
			m1.setLayoutY(332);
			
			//this button returns move2
			Button m2 = new Button("Use move 3");
			m2.setPrefSize(133,79);
			m2.setLayoutX(237);
			m2.setLayoutY(332);
			
			//this button returns move3
			Button m3 = new Button("Use move 4");
			m3.setPrefSize(133,79);
			m3.setLayoutX(65);
			m3.setLayoutY(441);
			
			//this button returns move4
			Button m4 = new Button("Use Item");
			m4.setPrefSize(133,79);
			m4.setLayoutX(237);
			m4.setLayoutY(441);
			
			//This choice box shows you the items you can use
			ChoiceBox<String> s = new ChoiceBox<String>();
			s.setPrefSize(112, 25);
			s.getItems().add("Potion");
			s.setLayoutX(608);
			s.setLayoutY(433);
			
			//this area shows the battle details
			TextArea t = new TextArea("Battle Description");
			t.setPrefSize(360,103);
			t.setLayoutX(466);
			t.setLayoutY(308);
			
			//this area shows your status, need to make a toString function for the Atk, def and spd value in order to change the value
			ListView<String> v = new ListView<String>();
			v.getItems().add("Atk");
			v.getItems().add("Def");
			v.getItems().add("Spd");
			v.setLayoutX(466);
			v.setLayoutY(433);
			v.setPrefSize(120,117);
			
			//this is player health bar, add in method to change the value of the bar, value is from 0 to 1
			ProgressBar hpBar1 = new ProgressBar(0.7);
			hpBar1.setPrefSize(300, 20);
			hpBar1.setStyle("-fx-accent: LIGHTGREEN");
			hpBar1.setLayoutX(60);
			hpBar1.setLayoutY(27);
			
			//this is enemy health bar
			ProgressBar hpBar2 = new ProgressBar(0.5);
			hpBar2.setPrefSize(300, 20);
			hpBar2.setStyle("-fx-accent: LIGHTGREEN");
			hpBar2.setLayoutX(828);
			hpBar2.setLayoutY(269);
			hpBar2.getTransforms().setAll(new Rotate(-180,0,0));
			
			//Scene 3 battle GUI creating
			Group battleScene = new Group();
			
			battleScene.getChildren().addAll(mv1,mv2,b,b2,m1,m2,m3,m4,s,t,v,hpBar1, hpBar2);
			Scene scene3 = new Scene(battleScene,width*cornersize,height*cornersize);
			scene3.setFill(Color.LIGHTBLUE);
			
			mainMap3.getPrimaryStage().setScene(scene3);
			mainMap3.getPrimaryStage().setTitle("Battle");
			mainMap3.getPrimaryStage().show();
			} catch(Exception e) {
				System.out.println("something bad");
			}
		}
	
	}
	
//add any methods here that you need to change the values 
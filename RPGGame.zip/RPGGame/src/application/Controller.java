package application;
import java.util.Random;

import logicClasses.*;
public class Controller {
	private Player player;
	private int xp;
	private Enemy lastEnemy;
	
	public Controller() {
		player = new Player("player");
		xp=0;
	}
	
	public Player getPlayer() {
		return player;
	}
	
	public void setName(String name) {
		if(!name.equals("Enter you player name here")) {
			player.setName(name);
		}
	}
	public String itemEvent() {
		Items item = AttainableItems.getItem();
		player.addItem(item);
		return item.getName();
	}
	
	public void healEvent() {
		player.setCurrentHp((int)(player.getCurrentHp()+player.getMaxHp()*0.2));
	}
	public PlayerBattle battleEvent() {
		PlayerBattle pb = new PlayerBattle(player);
		lastEnemy = pb.getEnemy();
		return pb;
	}

	public void finishedBattle(boolean win) {
		player.removeTempChanges();
		if(win) {
			xp+= lastEnemy.getTier() + 2;
			while(xp>=2) {
				Random r =new Random();
				player.levelUp(3);
				int[] statUp = new int[4];
				statUp[r.nextInt(4)]+=2;
				statUp[r.nextInt(4)]+=1;
				statUp[3]*=10;
				player.allotStats(statUp);
				xp-=2;
			}
		}
	}
}

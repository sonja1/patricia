package logicClasses;

public class PlayerBattle extends Battle{
	private Enemy enemy;
	private Player player;
	public PlayerBattle(Player aPlayer){
		super(aPlayer, new Enemy(aPlayer), true);
		player = aPlayer;
		enemy = (Enemy)character2;
		nextTurn();
		//System.out.println(this.character1);
		//System.out.println(this.character2);
		
	}
	
	public void nextTurn(){
		super.nextTurn();
		while(!this.isCharacter1Turn() && enemy.chooseMove(this.getWillPower())!=-1){
			this.useMove(enemy.chooseMove(this.getWillPower()));
			//System.out.println("ENEMY TURN");
		}
		if(!this.isCharacter1Turn()){
			super.nextTurn();
		}
		//System.out.println("Your Turn");
	}
	
	protected void checkState(){
		super.checkState();
		if(this.getState() == 1){
			character1.addItem(enemy.getDroppable());
		}
	}
	
	public Enemy getEnemy(){
		return enemy;
	}
	
	public Player getPlayer() {
		return player;
	}
}

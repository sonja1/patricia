package logicClasses;
public class Battle {
	protected Character character1;
	protected Character character2;
	private Character currentCharacter;
	private Character otherCharacter;
	private boolean character1Turn;// true if character1's turn false if character2's turn
	private int state=0; //0 if game is running, 1 if player1 won, -1 if player 2 won.
	private int willpower; //available actions of the current player

	/**
	 * creates a standard battle encounter, and initializes the first turn
	 * @param aCharacter1
	 * @param aCharacter2
	 */

	public Battle(Character aCharacter1, Character aCharacter2) {
		this(aCharacter1, aCharacter2, true);
		this.nextTurn();
	}
	/**
	 * creates a battle, but does not initialize the first turn
	 * @param aCharacter1
	 * @param aCharacter2
	 * @param differentiate
	 */
	//this constructor is needed for playerBattle to work since nextTurn method works differently within that child class
	protected Battle(Character aCharacter1, Character aCharacter2, boolean differentiate) { 
		character1 = aCharacter1;
		character2 = aCharacter2;
		if(character1.getSpd()>=character2.getSpd()){
			character1Turn = false;
		}
		else{
			character1Turn = true;
		}
	}
	/**
	 * initializes the next turn.
	 * Swaps turn, calculates current characterStats this turn, and calculates the total willPower of the turn
	 */
	public void nextTurn(){
		if(character1Turn){
			character1Turn = false;
			character2.statsNextTurn();
			currentCharacter = character2;
			otherCharacter = character1;
		}
		else{
			character1Turn = true;
			character1.statsNextTurn();
			currentCharacter = character1;
			otherCharacter = character2;
		}
		willpower = (currentCharacter.getSpd()*10 + (currentCharacter.getMaxHp()-currentCharacter.getCurrentHp()))/2;
	}
	/**
	 * checks if either character has won, or if their willPower this turn has ran out
	 */
	protected void checkState(){
		if(character1.getCurrentHp()<=0){
			state = -1;
		}
		else if(character2.getCurrentHp()<=0){
			state = 1;
		}
		else if(willpower<=0){
			this.nextTurn();
		}
	}
	/**
	 * uses move at specified int of the currentCharacter if it is a legal move. changes willpower if the move went through
	 * @param int moveIndex
	 */
	public void useMove(int moveIndex){
		if(currentCharacter.getKnownMoves() > moveIndex){//checks whether current character knows the specific move
			Move move = currentCharacter.getMove(moveIndex);
			if(willpower-move.getWillpower()>=0){//checks if the currentCharacter has enough willlpower to perform the move.
				if(move.getEnemyTargetted()){//targets appropriate target
					otherCharacter.useMove(move, currentCharacter);
				}
				else{
					currentCharacter.useMove(move,currentCharacter);
				}
				willpower-= move.getWillpower();
			}		
		}
		this.checkState();
	}
	/**
	 * uses item at specified int of currentCharacter if it is a legal item. changes willpower if the item is used
	 * @param int itemIndex
	 */
	public void useItem(int itemIndex){
		if(currentCharacter.getItems().size()>itemIndex){//checks if the player has specified item
			int itemWillpower = currentCharacter.getItem(itemIndex).getWillpower();
			if(willpower-itemWillpower>=0){//checks if there is sufficient willPower to useItem
				willpower -= itemWillpower;
				currentCharacter.useItem(itemIndex);
			}
		}
		this.checkState();
	}
	/**
	 * unequip's an item on currentCharacter
	 * @param equipIndex
	 */
	public void unequip(int equipIndex){
		currentCharacter.unequip(equipIndex);
	}
	/**
	 * returns 0 if battle is going, 1 if character1 has won, -1 if character2 has won.
	 * @return int state
	 */
	public int getState(){
		return state;
	}
	/**
	 * true if it is character1's turn, false otherwise
	 * @return boolean character1Turn
	 */
	public boolean isCharacter1Turn(){
		return character1Turn;
	}
	/**
	 * gets the willPower available in the current turn
	 * @return int willpower
	 */
	public int getWillPower(){
		return willpower;
	}

}

package application;

//import javafx.scene.image.Image;
//import javafx.scene.image.ImageView;

import java.util.ArrayList;

import java.util.List;
import java.util.Random;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;


public class mainMap3 extends Application {
	private static int speed = 5;
	private static ArrayList<int[]> battle = new ArrayList<int[]>();
	private static ArrayList<int[]> itemDrop = new ArrayList<int[]>();
	private static ArrayList<int[]> healSpot = new ArrayList<int[]>();
	private static int width = 36;
	private static int height = 24;
	private static int cornersize = 25;
	private static List<Corner>player = new ArrayList<>();
	private static Dir direction = Dir.space;
	private static boolean battleHappen = false;
	private static boolean foundItem = false;
	private static boolean healPlayer = false;
	private static Random rand = new Random();
	private static Scene scene1, scene2;
	private static battleGUI bGUI = new battleGUI();
	private static Stage mapStage;
	private static Controller controller = new Controller();
	
	public Controller getController() {
		return controller;
	}
	
	public enum Dir{
		up, down, left, right, space
	}
	
	public static Stage getPrimaryStage() {
		return mapStage;
	}
	
	public static Scene getScene1() {
		return scene1;
	}
	
	public static Scene getScene2() {
		return scene2;
	}
	
	public static class Corner{
		int x;
		int y;
		
		public Corner(int x, int y) {
			this.x = x;
			this.y = y;
		}
	}
		
	
	@Override
	public void start(Stage primaryStage) {
		mapStage = primaryStage;
		
		try {
			// Scene 1 Main menu creating
			//this shows the background image of main menu 
			//Source: https://www.lifewire.com/thmb/NcRvlBDBa7uYH8Iuwag2jaLTmys=/960x540/filters:fill(auto,1)/xenoblade-chronicles-2-5c1797f4c9e77c00016f0bbd.jpg
			ImageView iv1 = new ImageView();
			Image m1 = new Image("file:Images/main.jpg");
			iv1.setImage(m1);
			iv1.setFitWidth(width*cornersize+10);
			iv1.setFitHeight(height*cornersize+10);
			
			//click the button switch to scene2, aka the map
			Button s = new Button("Play!");
			s.setPrefSize(100,50);
			s.setTextFill(Color.RED);
			s.setLayoutX(407);
			s.setLayoutY(460);
			s.setOnAction(e -> primaryStage.setScene(scene2));
			
			//First label show welcome game
			Label w1 = new Label("Welcome to Dummy RPG! Press play to start the game!");
			w1.setTextFill(Color.PURPLE);
			w1.setFont(new Font(30));
			w1.setPrefSize(731,106);
			w1.setLayoutX(96);
			w1.setLayoutY(118);
			
			//box to contain the label
			Rectangle fw1 = new Rectangle();
			fw1.setWidth(750);
			fw1.setHeight(60);
			fw1.setLayoutX(90);
			fw1.setLayoutY(140);
			fw1.setFill(Color.LIGHTBLUE);
			
			//This is where you input the player name, make a method that stores the name from here
			TextField t = new TextField("Enter you player name here");
			t.setPrefSize(300, 30);
			t.setLayoutX(300);
			t.setLayoutY(265);
			
			//creating scene1 main menu
			Pane menu = new Pane();
			menu.getChildren().addAll(iv1,s,fw1,w1,t);
			scene1 = new Scene(menu,width*cornersize,height*cornersize);
			
			
			//Scene 2 main map creating
			newEvent();
			VBox map = new VBox();
			Canvas c = new Canvas(width*cornersize, height*cornersize);
			GraphicsContext gc = c.getGraphicsContext2D();
			
			map.getChildren().addAll(c);
			
			new AnimationTimer() {
				long lastTick = 0;
				
				public void handle(long now) {
					if (lastTick == 0) {
						lastTick = now;
						tick(gc);
					//	return;
					}
					if (now-lastTick > 500000000/speed) {
						lastTick = now;
						tick(gc);				
					}
				}
			}.start();
			
			
			scene2 = new Scene(map,width*cornersize,height*cornersize);
			
			//controls
			scene2.addEventFilter(KeyEvent.KEY_PRESSED,key ->{
				if (key.getCode() == KeyCode.SPACE) {
					direction = Dir.space;
				}
				if (key.getCode() == KeyCode.UP) {
					direction = Dir.up;
				}
				if (key.getCode() == KeyCode.DOWN) {
					direction = Dir.down;
				}
				if (key.getCode() == KeyCode.LEFT) {
					direction = Dir.left;
				}
				if (key.getCode() == KeyCode.RIGHT) {
					direction = Dir.right;
				}
			});
			
			scene2.addEventFilter(KeyEvent.KEY_RELEASED, key ->{
				direction = Dir.space;
			});
			
			//add starting player into map
			player.add(new Corner(width/2, height/2));
			
			scene2.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			
			//display the window
			primaryStage.setScene(scene1);
			primaryStage.setTitle("Dummy RPG");
			primaryStage.setResizable(false);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	//tick
	public void tick (GraphicsContext gc) {
		
		for (int i = player.size()-1; i >=1; i--) {
			player.get(i).x = player.get(i-1).x;
			player.get(i).y = player.get(i-1).y;
		}
		
		//check keys for collisions for the events
		
		switch(direction) {
		case up:
			player.get(0).y--;
			if(player.get(0).y < 0) {
				player.get(0).y = 0;
			}
			for(int[] e:battle) {
				if(e[0] == player.get(0).x && e[1] == player.get(0).y) {
					battleHappen = true;
				}
			}
			
			for(int[] i:itemDrop) {
				if(i[0] == player.get(0).x && i[1] == player.get(0).y) {
					foundItem = true;
				}
			}
			
			for (int [] h:healSpot) {
				if(h[0] == player.get(0).x && h[1] == player.get(0).y) {
					healPlayer = true;
				}
			}
			break;
		
			
		case down:
			player.get(0).y++;
			if(player.get(0).y >= height) {
				player.get(0).y = height - 1;
			}
			for(int[] e:battle) {
				if(e[0] == player.get(0).x && e[1] == player.get(0).y) {
					battleHappen = true;
				}
			}
			
			for(int[] i:itemDrop) {
				if(i[0] == player.get(0).x && i[1] == player.get(0).y) {
					foundItem = true;
				}
			}
			
			for (int [] h:healSpot) {
				if(h[0] == player.get(0).x && h[1] == player.get(0).y) {
					healPlayer = true;
				}
			}
			break;
			
		case left:
			player.get(0).x--;
			if(player.get(0).x < 0) {
				player.get(0).x = 0;
			}
			for(int[] e:battle) {
				if(e[0] == player.get(0).x && e[1] == player.get(0).y) {
					battleHappen = true;
				}
			}
			
			for(int[] i:itemDrop) {
				if(i[0] == player.get(0).x && i[1] == player.get(0).y) {
					foundItem = true;
				}
			}
			
			for (int [] h:healSpot) {
				if(h[0] == player.get(0).x && h[1] == player.get(0).y) {
					healPlayer = true;
				}
			}
			break;
			
		case right:
			player.get(0).x++;
			if(player.get(0).x >= width) {
				player.get(0).x = width - 1;
			}
			for(int[] e:battle) {
				if(e[0] == player.get(0).x && e[1] == player.get(0).y) {
					battleHappen = true;
				}
			}
			
			for(int[] i:itemDrop) {
				if(i[0] == player.get(0).x && i[1] == player.get(0).y) {
					foundItem = true;
				}
			}
			
			for (int [] h:healSpot) {
				if(h[0] == player.get(0).x && h[1] == player.get(0).y) {
					healPlayer = true;
				}
			}
			break;
			
		default:
			break;
		}
		
		
	
		
		//background color
		gc.setFill(Color.WHITE);
		gc.fillRect(0,0,width*cornersize, height*cornersize);

		
		//event colors
		Color ec = Color.WHITE;
	
		for(int[] e:battle) {
			gc.setFill(Color.RED);
			gc.fillOval(e[0]*cornersize,e[1]*cornersize,cornersize,cornersize);
		}
		
		for(int[] i:itemDrop) {
			gc.setFill(Color.YELLOW);
			gc.fillOval(i[0]*cornersize,i[1]*cornersize,cornersize,cornersize);
		}
		
		for (int[] h:healSpot) {
			gc.setFill(Color.LIGHTGREEN);
			gc.fillOval(h[0]*cornersize, h[1]*cornersize, cornersize, cornersize);
		}
		
		ec = Color.WHITE;
		gc.setFill(ec);
		
		
		
		//put player on map
		for (Corner c:player) {
			
			gc.setFill(Color.BLUE);
			gc.fillRect(c.x*cornersize,c.y*cornersize,cornersize-1,cornersize-1);
			gc.setFill(Color.LIGHTBLUE);
			gc.fillRect(c.x*cornersize,c.y*cornersize,cornersize-1,cornersize-1);
			
			
			//stat display, these values can be change using a toString method 
			gc.setFill(Color.DARKGREEN);
			gc.setFont(new Font("",20));
			//need method to get the data from the text field for player name
			gc.fillText("Player name: " + controller.getPlayer().getName(),20,30);  
			gc.fillText(("HP: (" + controller.getPlayer().getCurrentHp() + "/" + controller.getPlayer().getMaxHp() +")"),20,50);
			gc.fillText(("Atk: " +controller.getPlayer().getAtk()),20,70);
			gc.fillText(("Def: " + controller.getPlayer().getDef()),20,90);
			
		}
		
		
		//here is the collision for encounter battle	
		if (battleHappen) {
			gc.setFill(Color.RED);
			gc.setFont(new Font("BOLD", 50));
			gc.fillText("Press space to enter battle",150, 300);
			
			scene2.addEventFilter(KeyEvent.KEY_PRESSED, key ->{
				battleHappen = false;
				if (key.getCode() == KeyCode.SPACE) {
					for (int[] e:battle) {
						if (e[0] == player.get(0).x && e[1] == player.get(0).y) {	
							battle.remove(e);
							battle.add(new int[] {rand.nextInt(width),rand.nextInt(height)});
							//this code here switches scene to battleGUI
							bGUI.setPlayerBattle(controller.battleEvent());
							bGUI.battleStage(this);
						}
					}	
				}
			});
		}
		
		// here is the collision for items
		if (foundItem) {
			gc.setFill(Color.ORANGE);
			gc.setFont(new Font("", 50));
			gc.fillText("You've found an item!",210, 300);
			scene2.addEventFilter(KeyEvent.KEY_PRESSED, key ->{
				foundItem = false;
				for (int[] i:itemDrop) {
					if (i[0] == player.get(0).x && i[1] == player.get(0).y) {
						controller.itemEvent();
						itemDrop.remove(i);
						itemDrop.add(new int[] {rand.nextInt(width),rand.nextInt(height)});
					}
				}
			});
		}
		
		//here is the collision for healing player
		if (healPlayer) {
			gc.setFill(Color.GREEN);
			gc.setFont(new Font("", 50));
			gc.fillText("Recovered to full health!", 200, 300);
			scene2.addEventFilter(KeyEvent.KEY_PRESSED, key ->{
				healPlayer = false;
				for (int[] h:healSpot) {
					if (h[0] == player.get(0).x && h[1] == player.get(0).y) {
						controller.healEvent();
						healSpot.remove(h);
						healSpot.add(new int[] {rand.nextInt(width), rand.nextInt(height)});
					}
				}
			});
			
		}
	}

	
	//events, here collects all the data of the events into a list
	public static void newEvent() {
	
		for (int i = 0; i < 10; i++) {
			int[] enemy = new int[2];
			enemy[0] = rand.nextInt(width);
			enemy[1] = rand.nextInt(height);
			battle.add(enemy);
		}
		
		for (int i = 0; i < 4; i++) {
			int[] item = new int[2];
			item[0] = rand.nextInt(width);
			item[1] = rand.nextInt(height);
			itemDrop.add(item);
		}
		
		for (int i = 0; i < 3;i++) {
			int[] heal = new int[2];
			heal[0] = rand.nextInt(width);
			heal[1] = rand.nextInt(height);
			healSpot.add(heal);
		}
		
		start: while(true) {
			for (Corner c: player) {
				for (int[] e:battle) {
					if(c.x == e[0] && c.y == e[1]) {
						continue start;
					}
				}
			}
			for (Corner c: player) {
				for (int[] i:itemDrop) {
					if(c.x == i[0] && c.y == i[1]) {
						continue start;
					}
				}
			}
			for (Corner c:player) {
				for (int [] h:healSpot) {
					if(c.x == h[0] && c.y == h[1]) {
						continue start;
					}
				}
			}
			break;
		}
	}
	
	
	public static void main(String[] args) {
		
		launch(args);

	}
}

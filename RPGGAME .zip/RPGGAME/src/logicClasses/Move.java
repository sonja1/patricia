package logicClasses;
import java.util.Arrays;

public class Move {
	private final int NUMSTATS = 4;
	private String name;
	private int power;
	private double accuracy = 0;
	private int[] statChanges = new int[NUMSTATS];
	private boolean enemyTargetted;
	private int effectTurns;
	private int willpower;
	/**
	 * constructs a move based on the arguments passed in
	 * @param name
	 * @param willpower
	 * @param enemyTargetted
	 * @param statChanges
	 * @param effectTurns
	 * @param power
	 * @param accuracy
	 */
	public Move (String name,int willpower, boolean enemyTargetted, int[] statChanges,
			int effectTurns, int power, double accuracy) {
		this.setName(name);
		this.setPower(power);
		this.setAccuracy(accuracy);
		this.setEnemyTargetted(enemyTargetted);
		this.setStatChanges(statChanges);
		this.setEffectTurns(effectTurns);
		this.setWillpower(willpower);
	}
	/**
	 * creates a copy of the move passed in
	 * @param copy
	 */
	public Move (Move copy) {
		this.setName(copy.name);
		this.setPower(copy.power);
		this.setAccuracy(copy.accuracy);
		this.setEnemyTargetted(copy.enemyTargetted);
		this.setStatChanges(copy.statChanges);
		this.setEffectTurns(copy.effectTurns);
		this.setWillpower(copy.willpower);
	}

	//getters and setters
	/**
	 * gets name
	 * @return name
	 */
	public String getName() {
		return name;
	}
	/**
	 * sets name
	 * @param newName
	 */
	public void setName(String newName) {
		name = newName;
	}
	/**
	 * gets willpower
	 * @return willpower
	 */
	public int getWillpower() {
		return willpower;
	}
	/**
	 * sets willpower
	 * @param newWillpower
	 */
	public void setWillpower(int newWillpower) {
		willpower = newWillpower;
	}
	/**
	 * gets power
	 * @return power
	 */
	public int getPower() {
		return power; 
	}
	/**
	 * sets power
	 * @param newPower
	 */
	public void setPower(int newPower) {
		power = newPower;
	}
	/**
	 * gets accuracy
	 * @return accuracy
	 */
	public double getAccuracy() {
		return accuracy;
	}
	/**
	 * sets accuracy to a double between 0, and 1
	 * @param newAccuracy
	 */
	public void setAccuracy(double newAccuracy) {
		if(newAccuracy <= 1 && newAccuracy >= 0) {
			accuracy = newAccuracy;
		}
		else{
			accuracy=1.0;
		}
	}
	/**
	 * returns true if move targets opposing character, false if it targets the character casting it
	 * @return enemyTargetter
	 */
	public boolean getEnemyTargetted() {
		return enemyTargetted;
	}
	/**
	 * sets if it targets enemy
	 * @param isEnemyTargetted
	 */
	public void setEnemyTargetted(boolean isEnemyTargetted) {
		enemyTargetted = isEnemyTargetted;
	}
	/**
	 * gets the statChange array 
	 * @return statChanges
	 */
	public int[] getStatChanges() {
		return Arrays.copyOfRange(statChanges,0,NUMSTATS);
	}
	/**
	 * returns a specific statChange
	 * @param i
	 * @return statChage
	 */
	public int getStatChange(int i) {
		return statChanges[i];	
	}
	/**
	 * sets stat change array
	 * @param newStatChanges
	 */
	public void setStatChanges(int[] newStatChanges) {
		System.arraycopy(newStatChanges, 0, statChanges, 0, NUMSTATS);
	}
	/**
	 * sets a specific statChange
	 * @param i
	 * @param change
	 */
	public void setStatChange(int i, int change) {
		if(i<NUMSTATS){
			statChanges[i] = change;
		}
	}
	/**
	 * sets effectTurns
	 * @param newEffectTurns
	 */
	public void setEffectTurns(int newEffectTurns){
		if(newEffectTurns >= 0){
			effectTurns = newEffectTurns;
		}
		else {
			effectTurns = 0;
		}
	}
	/**
	 * gets effectTurns
	 * @return effectTurns
	 */
	public int getEffectTurns(){
		return effectTurns;
	}

}

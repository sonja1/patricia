package application;
import java.util.Random;

import logicClasses.*;
public class Controller {
	private Player player;
	private int xp;
	
	public Controller() {
		player = new Player("player");
		player.setCurrentHp(40);
		xp=0;
	}
	
	public Player getPlayer() {
		return player;
	}
	
	public String itemEvent() {
		Items item = AttainableItems.getItem();
		player.addItem(item);
		//System.out.println(player);
		return item.getName();
	}
	
	public void healEvent() {
		player.setCurrentHp((int)(player.getCurrentHp()+player.getMaxHp()*0.2));
	}
	public PlayerBattle battleEvent() {
		return new PlayerBattle(player);
	}
	public void finishedBattle(PlayerBattle pb) {
		xp+= pb.getEnemy().getTier();
		while(xp>=10) {
			Random r =new Random();
			player.levelUp(3);
			int[] statUp = new int[4];
			statUp[r.nextInt(4)]+=2;
			statUp[r.nextInt(4)]+=1;
			player.allotStats(statUp);
			xp-=10;
		}
	}
}

package application;

import javafx.collections.ObservableList;
import javafx.scene.Group;
import javafx.scene.Scene;


import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.transform.Rotate;
import logicClasses.*;




public class battleGUI{
	private int width = 36;
	private int height = 24;
	private static int cornersize = 25;
	private static Button b;
	private static Button b2;
	private static Button m1;
	private static Button m2;
	private static Button m3;
	private static Button m4;
	private static ChoiceBox<String> s;
	private static TextArea t;
	private static ListView<String> v;
	private static ProgressBar hpBar1;
	private static ProgressBar hpBar2;

	private Controller controller;
	private PlayerBattle pb;
	public void setController(Controller cont) {
		controller = cont;
		pb = controller.battleEvent();
	}

	//creating the stage for battleGUI
	public void battleStage(mainMap3 mOrgin){

		try {

			//this shows the image of player
			ImageView mv1 = new ImageView();
			Image p1 = new Image("file:Images/main-player.png");
			mv1.setImage(p1);
			mv1.setFitWidth(200);
			mv1.setFitHeight(200);
			mv1.setLayoutX(120);
			mv1.setLayoutY(90);

			//this shows the image of enemy
			ImageView mv2 = new ImageView();
			Image e1 = new Image("file:Images/enemy.png");
			mv2.setImage(e1);
			mv2.setFitWidth(200);
			mv2.setFitHeight(200);
			mv2.setLayoutX(570);
			mv2.setLayoutY(30);

			// this button takes you back to the map
			b = new Button("Next Turn");
			b.setPrefSize(225,69);
			b.setLayoutX(599);
			b.setLayoutY(480);
			b.setStyle("-fx-font-size: 3em; -fx-background-color: #f80606");
			b.setOnAction(e -> bButton());

			// this button allows you to use the selected item
			b2 = new Button("Use Item");
			b2.setPrefSize(98,25);
			b2.setLayoutX(726);
			b2.setLayoutY(433);
			b2.setOnAction(e -> b2Button());
			// use this to have the button do what you need b.setOnAction(e -> );

			//this button returns move1
			m1 = new Button("Use move 1");
			m1.setPrefSize(133,79);
			m1.setLayoutX(65);
			m1.setLayoutY(332);
			m1.setOnAction(e -> mButton(0));

			//this button returns move2
			m2 = new Button("Use move 2");
			m2.setPrefSize(133,79);
			m2.setLayoutX(237);
			m2.setLayoutY(332);
			m2.setOnAction(e -> mButton(1));

			//this button returns move3
			m3 = new Button("Use move 3");
			m3.setPrefSize(133,79);
			m3.setLayoutX(65);
			m3.setLayoutY(441);
			m3.setOnAction(e -> mButton(2));

			//this button returns move4
			m4 = new Button("Use move 4");
			m4.setPrefSize(133,79);
			m4.setLayoutX(237);
			m4.setLayoutY(441);
			m4.setOnAction(e -> mButton(4));

			//This choice box shows you the items you can use
			s = new ChoiceBox<String>();
			for(Items item: pb.getPlayer().getItems()) {
				s.getItems().add(item.getName());
			}
			s.setPrefSize(112, 25);
			s.setLayoutX(608);
			s.setLayoutY(433);

			//this area shows the battle details
			t = new TextArea("Battle Description");
			t.setPrefSize(360,103);
			t.setLayoutX(466);
			t.setLayoutY(308);

			//this area shows your status, need to make a toString function for the Atk, def and spd value in order to change the value
			v = new ListView<String>();
			v.getItems().add("Atk: " + pb.getPlayer().getAtk());
			v.getItems().add("Def: " + pb.getPlayer().getDef());
			v.getItems().add("Spd: " + pb.getPlayer().getSpd());
			v.getItems().add("Wlp: " + pb.getWillPower());
			v.setLayoutX(466);
			v.setLayoutY(433);
			v.setPrefSize(120,117);

			//this is player health bar, add in method to change the value of the bar, value is from 0 to 1
			hpBar1 = new ProgressBar((double)pb.getEnemy().getCurrentHp()/pb.getEnemy().getMaxHp());
			hpBar1.setPrefSize(300, 20);
			hpBar1.setStyle("-fx-accent: LIGHTGREEN");
			hpBar1.setLayoutX(60);
			hpBar1.setLayoutY(27);

			//this is enemy health bar
			hpBar2 = new ProgressBar((double)pb.getPlayer().getCurrentHp()/pb.getPlayer().getMaxHp());
			hpBar2.setPrefSize(300, 20);
			hpBar2.setStyle("-fx-accent: LIGHTGREEN");
			hpBar2.setLayoutX(828);
			hpBar2.setLayoutY(269);
			hpBar2.getTransforms().setAll(new Rotate(-180,0,0));

			//Scene 3 battle GUI creating
			Group battleScene = new Group();

			battleScene.getChildren().addAll(mv1,mv2,b,b2,m1,m2,m3,m4,s,t,v,hpBar1, hpBar2);
			Scene scene3 = new Scene(battleScene,width*cornersize,height*cornersize);
			scene3.setFill(Color.LIGHTBLUE);

			mainMap3.getPrimaryStage().setScene(scene3);
			mainMap3.getPrimaryStage().setTitle("Battle");
			mainMap3.getPrimaryStage().show();
		} catch(Exception e) {
			System.out.println("something bad");
		}
	}
	private void update() {
		hpBar1.setProgress((double)pb.getEnemy().getCurrentHp()/pb.getEnemy().getMaxHp());
		hpBar2.setProgress((double)pb.getPlayer().getCurrentHp()/pb.getPlayer().getMaxHp());
		for(int i = 0; i<s.getItems().size(); i++) {
			if(pb.getPlayer().getItem(i)!=null) {
				s.getItems().set(i, pb.getPlayer().getItem(i).getName());
			}
			else {
				s.getItems().remove(i);
			}
		}
		v.getItems().set(0, "Atk: " + pb.getPlayer().getAtk());
		v.getItems().set(1, "Def: " + pb.getPlayer().getDef());
		v.getItems().set(2, "Spd: " + pb.getPlayer().getSpd());
		v.getItems().set(3, "Wlp: " + pb.getWillPower());
		if(pb.getState()!=0) {
			if(pb.getState()==1) {
				controller.finishedBattle(true);
			}
			else {
				controller.finishedBattle(false);
			}
			mainMap3.getPrimaryStage().setScene(mainMap3.getScene2());
		}
	}
	
	private void mButton(int i) {
		pb.useMove(i);
		update();
	}
	
	private void bButton() {
		pb.nextTurn();
		update();
	}
	private void b2Button() {
		boolean found = false;
		for(int i = 0; i<pb.getPlayer().getItems().size() && !found;i++) {
			found = s.getSelectionModel().isSelected(i);
			if(found) {
				System.out.println(pb.getPlayer());
				pb.useItem(i);
			}
		}
		update();
	}

}

//add any methods here that you need to change the values 
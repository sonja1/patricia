package logicClasses;
import java.util.ArrayList;
import java.util.Random;

/**
 * Represents an enemy in the game.
 * Child of character class, also has a tier and a droppable item.
 */

public class Enemy extends Character {
	private Items droppable;
	private int tier;


	//Constructors
	/**
	 * Creates an enemy with respect to the player passed in with slightly different stats.
	 */
	public Enemy (Player aPlayer) {
		super(aPlayer);
		super.setName("Enemy");
		Random random = new Random();
		this.tier = random.nextInt(3)-1;
		this.setAtk((int)((double)((1+ (double) tier/10.0)*aPlayer.getAtk())));
		this.setDef((int)((double)((1+ (double) tier/10.0)*aPlayer.getDef())));
		this.setSpd((int)((double)((1+ (double) tier/10.0)*aPlayer.getSpd())));
		this.setMaxHp((int)((double)((1+ (double) tier/10.0)*aPlayer.getMaxHp())));
		this.setCurrentHp((int)((double)((1+ (double) tier/10.0)*aPlayer.getMaxHp())));
		this.droppable = AttainableItems.getItem(); 
		this.addMove(LearnableMoves.getMove(-1));
		for(int i = 0; i<aPlayer.getLevel()/3; i++) {
			if(this.getKnownMoves()<4) {
				this.addMove(LearnableMoves.getMove(i));
			}
			else {
				this.replaceMove(0, LearnableMoves.getMove(i));
			}
		}
	}

	/**
	 * Copy constructor, copies another enemy.
	 */
	public Enemy (Enemy anEnemy) {
		super(anEnemy);
		this.tier = anEnemy.tier;
		this.droppable = anEnemy.droppable;
	}


	//Getters
	/**
	 * Gets the enemy's tier.
	 * @return the enemy's tier.
	 */
	public int getTier() {
		return this.tier;
	}
	/**
	 * Gets the enemies drop.
	 * @return the enemy's item drop.
	 */
	public Items getDroppable() {
		return this.droppable;
	}

	//Setters
	/**
	 * Sets the tier of the enemy, must be an integer from -1 to 1.
	 */
	public void setTier(int aTier) {
		if (aTier == 1 || aTier == 0 || aTier == -1) {
			tier = aTier;
		}
	}

	/**
	 * Enemy randomly chooses move based on the willpower passed in.
	 * @param aWillpower, an integer.
	 * @returns index of a move (integer from 0-3), or -1 if there is no usable move
	 */
	public int chooseMove(int aWillpower) { 
		ArrayList<Integer> list = new ArrayList<Integer>();
		for (int i = 0; i < super.getKnownMoves(); i++) {
			if (this.getMove(i).getWillpower() < aWillpower) {
				list.add(i);
			}
		}
		if (list.isEmpty()) {//no usable moves with respect to the willpower/the enemy knows no moves
			return -1;
		}
		else { 
			Random random = new Random();
			return list.get(random.nextInt(list.size()));

		}
	}

}

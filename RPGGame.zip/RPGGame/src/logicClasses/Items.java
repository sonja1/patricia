package logicClasses;
import java.util.Arrays;

public class Items {
	private final int NUMSTATS = 4;
	private final int EQUIPSLOTS = 6;
	private int power;
	private boolean consumable;
	private String itemName;
	private int[] statChange = new int[NUMSTATS];
	private int effectTurns;
	private int equipmentType;
	private int willpower;
	/**
	 * constructs an item
	 * @param itemName
	 * @param willpower
	 * @param consumable, true if consumable, false if equippable
	 * @param statChange
	 * @param effectTurnsOrType, changes effectTurns if its consumable, changes equipmentType if its equippable.
	 * @param power, only set if the item is consumable
	 */
	public Items(String itemName,int willpower, boolean consumable,
			int[] statChange,  int effectTurnsOrType, int power) {
		setConsumable(consumable);
		setName(itemName);
		setStatChanges(statChange);
		this.setWillpower(willpower);
		if(consumable){
			setEffectTurns(effectTurnsOrType);
			setEquipmentType(-1);
			setPower(power);
		}
		else{
			setEffectTurns(-1);
			setEquipmentType(effectTurnsOrType);
			setPower(0);
		}
	}
	/**
	 * constructs a copy of an item
	 * @param aCopy
	 */
	public Items(Items aCopy) {
		itemName = aCopy.itemName;
		consumable = aCopy.consumable;
		statChange = aCopy.statChange;
		power = aCopy.power;
		effectTurns = aCopy.effectTurns;
		equipmentType = aCopy.equipmentType;
		willpower = aCopy.willpower;

	}
	//setter
	/**
	 * sets whether the item is consumable or not
	 * @param ifConsumable
	 */
	public void setConsumable(boolean ifConsumable) {
		consumable = ifConsumable;
	}
	/**
	 * sets name
	 * @param aName
	 */
	public void setName(String aName) {
		itemName = aName;	
	}	
	/**
	 * sets effect turns (only works if item is consumable)
	 * @param change
	 */
	public void setEffectTurns(int change){
		if(consumable){
			effectTurns = change;
		}
	}
	/**
	 * sets equipmentType (only works if item is equippable)
	 * @param change
	 */
	public void setEquipmentType(int change){
		if(!consumable){
			if(change<EQUIPSLOTS && change>=0){
				equipmentType = change;
			}
			else{
				equipmentType =0;
			}
		}
	}
	/**
	 * sets a specific statChange in the statChange array
	 * @param i
	 * @param change
	 */
	public void setStatChange(int i, int change) {
		if (i<NUMSTATS) {
			statChange[i] = change;
		}
	}
	/**
	 * sets the statChange array to the array passed in
	 * @param newStatChange
	 */
	public void setStatChanges(int[] newStatChange) {
		System.arraycopy(newStatChange, 0, statChange, 0, NUMSTATS);
	}
	/**
	 * sets power
	 * @param change
	 */
	public void setPower(int change){
		power = change;
	}
	/**
	 * sets willPower (how much it costs to use the item)
	 * @param change
	 */
	public void setWillpower(int change){
		willpower = change;
	}

	//getter
	/**
	 * gets the type of item
	 * @return true if consumable, false if equippable
	 */
	public boolean isConsumable() {
		return consumable;
	}
	/**
	 * gets name
	 * @return name
	 */
	public String getName() {
		return itemName;
	}
	/**
	 * gets effectDuration
	 * @return effectTurns
	 */
	public int getEffectDuration(){
		return effectTurns;
	}
	/**
	 * gets equipmentType
	 * @return equipmentType
	 */
	public int getEquipmentType(){
		return equipmentType;
	}
	/**
	 * gets the statChangeArray
	 * @return statChange array
	 */
	public int[] getStatChange() {
		return Arrays.copyOfRange(statChange,0,NUMSTATS);
	}
	/**
	 * gets power
	 * @return power
	 */
	public int getPower(){
		return power;
	}
	/**
	 * gets willPower
	 * @return willpower
	 */
	public int getWillpower(){
		return willpower;
	}
}

package logicClasses;

public class PlayerBattle extends Battle{
	private Enemy enemy;
	private Player player;
	/**
	 * creates a battle with the player passed in and an enemy made in relation to the player
	 * @param aPlayer
	 */
	public PlayerBattle(Player aPlayer){
		super(aPlayer, new Enemy(aPlayer), true);
		player = aPlayer;
		enemy = (Enemy)character2;
		nextTurn();

	}
	/**
	 * same as parent class nextTurn(), if the turn is the enemy's turn it uses all the moves it can,
	 * then switches the turn back to the player
	 */
	public void nextTurn(){
		super.nextTurn();
		while(!this.isCharacter1Turn() && enemy.chooseMove(this.getWillPower())!=-1){
			this.useMove(enemy.chooseMove(this.getWillPower()));
		}
		if(!this.isCharacter1Turn()){
			super.nextTurn();
		}
	}
	/**
	 * same as parent class checkState(),
	 * gives the player an item if they won
	 */
	protected void checkState(){
		super.checkState();
		if(this.getState() == 1){
			player.addItem(enemy.getDroppable());
		}
	}
	/**
	 * gets enemy
	 * @return enemy
	 */
	public Enemy getEnemy(){
		return enemy;
	}
	/**
	 * gets player
	 * @return player
	 */
	public Player getPlayer() {
		return player;
	}
}

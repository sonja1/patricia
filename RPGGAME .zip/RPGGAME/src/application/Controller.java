package application;
import java.util.Random;
import logicClasses.*;


public class Controller {
	private Player player;
	private int xp;
	private Enemy lastEnemy;
	
	/**
	 * this method initiate player status and the xp
	 */
	public Controller() {
		player = new Player("player");
		xp=0;
	}
	
	/**
	 * getter method for the player
	 * @return player
	 */
	public Player getPlayer() {
		return player;
	}
	
	/**
	 * setter method for the player name
	 * @param name
	 */
	public void setName(String name) {
		if(!name.equals("Enter you player name here")) {
			player.setName(name);
		}
	}
	
	/**
	 * this method gives you the items in player's inventory
	 * @return item name
	 */
	public String itemEvent() {
		Items item = AttainableItems.getItem();
		player.addItem(item);
		return item.getName();
	}
	
	/**
	 * this method gives players current hp
	 */
	public void healEvent() {
		player.setCurrentHp((int)(player.getCurrentHp()+player.getMaxHp()*0.2));
	}
	
	/**
	 * this method returns the battle information for player 
	 * @return pb
	 */
	public PlayerBattle battleEvent() {
		PlayerBattle pb = new PlayerBattle(player);
		lastEnemy = pb.getEnemy();
		return pb;
	}

	/**
	 * this method updates the player status after the battle finished
	 * @param win
	 */
	public void finishedBattle(boolean win) {
		player.removeTempChanges();
		if(win) {
			xp+= lastEnemy.getTier() + 2;
			while(xp>=2) {
				Random r =new Random();
				player.levelUp(3);
				int[] statUp = new int[4];
				statUp[r.nextInt(4)]+=2;
				statUp[r.nextInt(4)]+=1;
				statUp[3]*=10;
				player.allotStats(statUp);
				xp-=2;
			}
		}
	}
}

package application;

//	import javafx.fxml.FXMLLoader;
//	import java.io.FileInputStream;
//	FXMLLoader loader = new FXMLLoader();
//	root = (VBox)loader.load(new FileInputStream("src/application/RPGDemoView.fxml"));//
//import javafx.scene.image.Image;
//import javafx.scene.image.ImageView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javafx.animation.AnimationTimer;
import javafx.application.Application;

import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;

import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;


public class mainMap extends Application {
	static int eventColor = 0;
	static int speed = 5;
//	static ArrayList<int[]> battle = new ArrayList<int[]>();
	static int battleX1 = 0;
	static int battleY1= 0;
	static int battleX2 = 0;
	static int battleY2 = 0;
	static int itemDropX1 = 0;
	static int itemDropY1 = 0;
	static int width = 20;
	static int height = 20;
	static int cornersize = 25;
	static List<Corner>player = new ArrayList<>();
	static Dir direction = Dir.space;
	static boolean battleHappen = false;
	static boolean foundItem = false;
	static Random rand = new Random();

	
	
	public enum Dir{
		up, down, left, right, space
	}
	
	
	public static class Corner{
		int x;
		int y;
		
		public Corner(int x, int y) {
			this.x = x;
			this.y = y;
		}
	}
		
	
	@Override
	public void start(Stage primaryStage) {
		try {
			newEvent();
			VBox root = new VBox();
			Canvas c = new Canvas(width*cornersize, height*cornersize);
			GraphicsContext gc = c.getGraphicsContext2D();
			
			root.getChildren().add(c);
			
			new AnimationTimer() {
				long lastTick = 0;
				
				public void handle(long now) {
					if (lastTick == 0) {
						lastTick = now;
						tick(gc);
						return;
					}
					if (now-lastTick > 500000000/speed) {
						lastTick = now;
						tick(gc);
						
					}
				}
			}.start();
			
			
			Scene scene = new Scene(root,width*cornersize,height*cornersize);
			
			//controls
			scene.addEventFilter(KeyEvent.KEY_PRESSED,key ->{
				if (key.getCode() == KeyCode.SPACE) {
					direction = Dir.space;
				}
				if (key.getCode() == KeyCode.UP) {
					direction = Dir.up;
				}
				if (key.getCode() == KeyCode.DOWN) {
					direction = Dir.down;
				}
				if (key.getCode() == KeyCode.LEFT) {
					direction = Dir.left;
				}
				if (key.getCode() == KeyCode.RIGHT) {
					direction = Dir.right;
				}
			});
			
			scene.addEventFilter(KeyEvent.KEY_RELEASED, key ->{
				direction = Dir.space;
			});
			
			
			//add starting player into map
			player.add(new Corner(width/2, height/2));
			
			
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setTitle("Dummy RPG");
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	//tick
	public static void tick (GraphicsContext gc) {
		if (battleHappen) {
			gc.setFill(Color.RED);
			gc.setFont(new Font("", 50));
			gc.fillText("Enter Battle",125, 250);
			return;
		}
		
		if (foundItem) {
			gc.setFill(Color.YELLOW);
			gc.setFont(new Font("", 30));
			gc.fillText("You've found an item!",105, 250);
			return;
		}
			
		
		for (int i = player.size()-1; i >=1; i--) {
			player.get(i).x = player.get(i-1).x;
			player.get(i).y = player.get(i-1).y;
		}
		
		//check collision for the events
		switch(direction) {
		case up:
			player.get(0).y--;
			if(player.get(0).y < 0) {
				player.get(0).y = 0;
			}
			if(battleX1 == player.get(0).x && battleY1 == player.get(0).y) {
				battleHappen = true;
			}
			if(battleX2 == player.get(0).x && battleY2 == player.get(0).y) {
				battleHappen = true;
			}
			if(itemDropX1 == player.get(0).x && itemDropY1 == player.get(0).y) {
				foundItem = true;
			}
			break;
			
		case down:
			player.get(0).y++;
			if(player.get(0).y >= height) {
				player.get(0).y = height-1;
			}
			if(battleX1 == player.get(0).x && battleY1 == player.get(0).y) {
				battleHappen = true;	
			}
			if(battleX2 == player.get(0).x && battleY2 == player.get(0).y) {
				battleHappen = true;
			}
			if(itemDropX1 == player.get(0).x && itemDropY1 == player.get(0).y) {
				foundItem = true;
			}
			break;
			
		case left:
			player.get(0).x--;
			if(player.get(0).x < 0) {
				player.get(0).x = 0;
			}
			if(battleX1 == player.get(0).x && battleY1 == player.get(0).y) {
				battleHappen = true;
			}
			if(battleX2 == player.get(0).x && battleY2 == player.get(0).y) {
				battleHappen = true;
			}
			if(itemDropX1 == player.get(0).x && itemDropY1 == player.get(0).y) {
				foundItem = true;
			}
			break;
			
		case right:
			player.get(0).x++;
			if(player.get(0).x >= width) {
				player.get(0).x = width-1;
			}
			if(battleX1 == player.get(0).x && battleY1 == player.get(0).y) {
				battleHappen = true;
			}
			if(battleX2 == player.get(0).x && battleY2 == player.get(0).y) {
				battleHappen = true;
			}
			if(itemDropX1 == player.get(0).x && itemDropY1 == player.get(0).y) {
				foundItem = true;
			}
			break;
			
		default:
			break;
		}
		
		
		//background color
		gc.setFill(Color.GREY);
		gc.fillRect(0,0,width*cornersize, height*cornersize);

		
		//event colors
		
		Color ec = Color.WHITE;
		
	
		ec = Color.RED;
		gc.setFill(ec);
		gc.fillOval(battleX1*cornersize,battleY1*cornersize,cornersize,cornersize);
		gc.fillOval(battleX2*cornersize,battleY2*cornersize,cornersize,cornersize);
		
		ec = Color.YELLOW;
		gc.setFill(ec);
		gc.fillOval(itemDropX1*cornersize,itemDropY1*cornersize,cornersize,cornersize);
		
		ec = Color.WHITE;
		gc.setFill(ec);
		
		
		
		//put player on map
		for (Corner c:player) {
			
		/*	Image ch = new Image ("file:image0.png");
			ImageView mv = new ImageView(ch);
			
			mv.setImage(ch);
		*/
			gc.setFill(Color.BLUE);
			gc.fillRect(c.x*cornersize,c.y*cornersize,cornersize-1,cornersize-1);
			gc.setFill(Color.LIGHTBLUE);
			gc.fillRect(c.x*cornersize,c.y*cornersize,cornersize-1,cornersize-1);
			
			
			//stat display
			gc.setFill(Color.DARKGREEN);
			gc.setFont(new Font("",20));
			gc.fillText("HP: 100/100", 20,30);
			gc.fillText("Attk:15",20,50);
			gc.fillText("Def:10", 20,70);
			
		/*	gc.setFill(Color.LIGHTBLUE);
			gc.setFont(new Font("",20));
			gc.fillText("Player : Dummy", 380, 30,80);
			gc.fillText("Press i for inventory", 380, 50,100);
		*/	
		}
	}

	
	//events
	public static void newEvent() {
		start: while(true) {
			battleX1 = rand.nextInt(width);
			battleY1 = rand.nextInt(height);
			
			battleX2 = rand.nextInt(width);
			battleY2 = rand.nextInt(height);
			
			itemDropX1 = rand.nextInt(width);
			itemDropY1 = rand.nextInt(height);
			
			
			for (Corner c: player){
				if(c.x == battleX1 && c.y == battleY1) {
					continue start;
					
				}
				if(c.x == battleX2 && c.y == battleX2) {
					continue start;
				
				}
				if(c.x == itemDropX1 && c.y == itemDropY1) {
					continue start;
				}
			}
			break;
		}
	}
	
	
	public static void main(String[] args) {
		launch(args);
	}
}
